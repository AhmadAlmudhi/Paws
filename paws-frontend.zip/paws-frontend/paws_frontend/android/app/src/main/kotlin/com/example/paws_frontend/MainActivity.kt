package com.example.paws_frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
